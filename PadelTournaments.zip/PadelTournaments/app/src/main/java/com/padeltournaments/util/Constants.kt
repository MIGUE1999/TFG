package com.padeltournaments.util

const val DATABASE_NAME = "padel-tournaments-db"
const val TAG = "MAIN"
const val TOURNAMENT_STARTED_DATE = "Fecha de Inicio"
const val TOURNAMENT_END_DATE = "Fecha de Fin"