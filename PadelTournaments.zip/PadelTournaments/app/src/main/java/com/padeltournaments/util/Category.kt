package com.padeltournaments.util

object Category {
    const val first = "Primera"
    const val second = "Segunda"
    const val third = "Tercera"
}