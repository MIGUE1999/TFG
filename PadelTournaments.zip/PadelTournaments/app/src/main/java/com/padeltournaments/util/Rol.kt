package com.padeltournaments.util

object Rol{
    const val player = "Jugador"
    const val organizer = "Organizador"
}